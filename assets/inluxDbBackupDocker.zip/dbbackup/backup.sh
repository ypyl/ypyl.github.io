#!/bin/bash
set -e

: ${INFLUX_HOST:?"INFLUX_HOST env variable is required"}

dir=/backup
min_dirs=16
#we are saving only last 14 backups (2 weeks)

if [ $(find "$dir" -maxdepth 1 -type d | wc -l) -ge $min_dirs ]
  then find "$dir" -maxdepth 1 | sort | head -n 2 | sort -r | head -n 1 | xargs rm -rf
fi

#all backups are in /backup folder
#every backup is in a folder with name which is date when a backup has been created
DATE=`date +%Y-%m-%d-%H-%M-%S`

echo 'Backup Influx metadata'
influxd backup -host $INFLUX_HOST:8088 /backup/$DATE

# Replace colons with spaces to create list.
for db in ${DATABASES//:/ }; do
  echo "Creating backup for $db"
  influxd backup -database $db -host $INFLUX_HOST:8088 /backup/$DATE
done
