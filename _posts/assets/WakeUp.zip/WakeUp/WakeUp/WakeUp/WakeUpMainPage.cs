﻿using System.Linq;
using Xamarin.Forms;

namespace WakeUp
{
    class WakeUpMainPage : CarouselPage
    {
        private static Thickness padding = new Thickness(0, Device.OnPlatform(40, 40, 0), 0, 0);

        private ContentPage CreateExercisePage(int index, string text, string img, string text2)
        {
            var btn = new Button
            {
                Text = "Next",
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.End
            };
            btn.Clicked += (sender, e) =>
            {
                CurrentPage = Children.ElementAt(index + 1);
            };

            var additionalInfo = new StackLayout
            {
                BackgroundColor = Color.FromHex("a9e3ee"),
                Padding = new Thickness(10, 0, 10, 0),
                HorizontalOptions = LayoutOptions.FillAndExpand,
                Children = {
                    new Label {
                        Text = text2,
                        TextColor = Color.Black,
                        FontSize = Device.GetNamedSize (NamedSize.Medium, typeof(Label)),
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalOptions = LayoutOptions.CenterAndExpand,
                    }
                }
            };

            var mainInfo = new StackLayout
            {
                BackgroundColor = Color.FromHex("ffe0bd"),
                Padding = new Thickness(10, 0, 10, 0),
                HorizontalOptions = LayoutOptions.FillAndExpand,
                Children = {
                    new Label {
                        Text = text,
                        TextColor = Color.Black,
                        FontSize = Device.GetNamedSize (NamedSize.Medium, typeof(Label)),
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalOptions = LayoutOptions.CenterAndExpand,
                    }
                }
            };

            return new ContentPage
            {
                Padding = padding,
                Content = new StackLayout
                {
                    Children = {
                        new Image
                        {
                            Aspect = Aspect.AspectFit,
                            HorizontalOptions = LayoutOptions.FillAndExpand,
                            VerticalOptions = LayoutOptions.FillAndExpand,
                            Source = ImageSource.FromResource(img)
                        },
                    mainInfo,
                    additionalInfo,
                    btn
                }
                }
            };
        }

        public WakeUpMainPage()
        {
            // welcome page
            var lblStart = new StackLayout
            {
                BackgroundColor = Color.FromHex("ffe0bd"),
                Padding = new Thickness(10, 0, 10, 0),
                VerticalOptions = LayoutOptions.CenterAndExpand,
                HorizontalOptions = LayoutOptions.FillAndExpand,
                Children = {
                    new Label
                    {
                        Text = "Let's do some morning exercises!",
                        TextColor = Color.Black,
                        FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
                        HorizontalOptions = LayoutOptions.CenterAndExpand,
                        VerticalOptions = LayoutOptions.CenterAndExpand
                    }
                }
            };

            var buttonStart = new Button
            {
                Text = "Start",
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.Center
            };
            buttonStart.Clicked += (sender, e) =>
            {
                CurrentPage = Children.ElementAt(1);
            };

            var welcomePage = new ContentPage
            {
                Padding = padding,
                Content = new StackLayout
                {
                    Children = {
                        lblStart,
                        buttonStart
                    }
                }
            };

            // head page

            var head = CreateExercisePage(1, "Slowly rotate the head first clockwise direction and then opposite", "WakeUp.head2.jpg", "Repeat - 3 laps in one direction and 3 - in other");
            var shoulder = CreateExercisePage(2, "Fasten fingers to the shoulders and rotate your hands back and forth", "WakeUp.shoulder2.jpg", "Repeat - 5 times in each direction");
            var tilt = CreateExercisePage(3, "Put your hands on the belt and do side bends alternately to the right and left, like a pendulum", "WakeUp.tilt2.jpg", "Repeat - 10 times in each direction");
            var floor = CreateExercisePage(4, "Stand straight, while inhaling raise the arms up and lean forward. Touch the floor with his hands. Inhale to straighten up", "WakeUp.floor2.jpg", "Repeat - 10 times");
            var squat = CreateExercisePage(5, "Stand up straight, feet shoulder width apart, hands on his belt.Squat with a straight back, trying not to tear the heel off the floor, and as low as possible", "WakeUp.squat2.jpg", "Repeat - 5-10 times");

            Children.Add(welcomePage);
            Children.Add(head);
            Children.Add(shoulder);
            Children.Add(tilt);
            Children.Add(floor);
            Children.Add(squat);
            var btnReset = new Button
            {
                Text = "Reset",
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.End
            };
            btnReset.Clicked += (sender, e) =>
            {
                CurrentPage = Children.ElementAt(0);
            };
            Children.Add(new ContentPage
            {
                Padding = padding,
                Content = new StackLayout
                {
                    Children = {
                        new StackLayout
                        {
                            BackgroundColor = Color.FromHex("ffe0bd"),
                            Padding = new Thickness(10, 0, 10, 0),
                            VerticalOptions = LayoutOptions.CenterAndExpand,
                            HorizontalOptions = LayoutOptions.FillAndExpand,
                            Children = {
                                new Label
                                {
                                    Text = "You did it! Have a nice day! All will be good! Smile!",
                                    TextColor = Color.Black,
                                    FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
                                    HorizontalOptions = LayoutOptions.Center,
                                    VerticalOptions = LayoutOptions.CenterAndExpand
                                }
                            }
                        },
                        btnReset
                    }
                }
            });

            BackgroundColor = Color.White;
        }
    }
}
