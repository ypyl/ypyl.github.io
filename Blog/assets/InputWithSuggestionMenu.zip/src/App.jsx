import React from 'react';
import InputWithSuggestionMenu from './InputWithSuggestionMenu'
export function App(props) {
  return (
    <div className='App'>
      <InputWithSuggestionMenu />
    </div>
  );
}
