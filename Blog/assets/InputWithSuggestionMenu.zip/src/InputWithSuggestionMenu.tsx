import React, { useState, useRef, KeyboardEvent } from 'react';
import { InputBase, MenuItem, Popover } from '@mui/material';

const InputWithSuggestionMenu = () => {
  const [inputValue, setInputValue] = useState('');
  const [suggestionMenuOpen, setSuggestionMenuOpen] = useState(false);
  const [suggestedItems, setSuggestedItems] = useState<any[]>([]);
  const [cursorPosition, setCursorPosition] = useState({ top: 0, left: 0 });
  const textInputRef = useRef<HTMLInputElement | null>(null);

  const suggestionOptions = [
    { value: 'GoogleSearch', text: 'Google Search' },
    { value: 'DatabaseLookup', text: 'Database Lookup' },
  ];

  const calculateCaretCoordinates = (element: HTMLInputElement, position: number) => {
    const div = document.createElement('div');
    const styles = window.getComputedStyle(element);
    for (let i = 0; i < styles.length; i++) {
      const name = styles[i];
      div.style.setProperty(name, styles.getPropertyValue(name));
    }
    const span = document.createElement('span');
    span.textContent = element.value.substring(0, position);
    div.appendChild(span);
    document.body.appendChild(div);
    const rect = element.getBoundingClientRect();
    const coordinates = {
      top: rect.top,
      left: span.offsetWidth + rect.left,
    };
    document.body.removeChild(div);
    return coordinates;
  };

  const openSuggestionMenu = () => {
    setSuggestionMenuOpen(true);
  };

  const closeSuggestionMenu = () => {
    setSuggestionMenuOpen(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);

    const cursorIndex = e.target.selectionStart;
    if (cursorIndex == null) return;

    // Detect "@" symbol
    const lastWord = newValue.slice(0, cursorIndex).split(' ').pop();
    if (lastWord?.startsWith('@')) {
      const searchQuery = lastWord.slice(1).toLowerCase();
      const newSuggestedItems = suggestionOptions.filter(option =>
        option.text.toLowerCase().includes(searchQuery),
      );
      if (newSuggestedItems.length === 0) {
        closeSuggestionMenu();
        return;
      }
      setSuggestedItems(newSuggestedItems);

      // Update caret position
      const { top, left } = calculateCaretCoordinates(e.target, cursorIndex);
      setCursorPosition({ top, left });
      openSuggestionMenu();
    } else {
      closeSuggestionMenu();
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    if (e.key === 'Escape') {
      closeSuggestionMenu();
      return;
    }
    if (suggestionMenuOpen && e.key === 'Enter') {
      e.preventDefault();
      if (suggestedItems.length > 0) {
        handleSuggestionSelect(suggestedItems[0].value);
      }
      return;
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
    }
  };

  const handleSuggestionSelect = (item: string) => {
    closeSuggestionMenu();
    console.log(`Selected tool: ${item}`);
  };

  return (
    <>
      <InputBase
        multiline
        autoFocus
        inputRef={textInputRef}
        maxRows={10}
        placeholder="Type something..."
        value={inputValue}
        onChange={handleInputChange}
        onKeyDown={handleKeyPress}
      />
      <Popover
        anchorReference="anchorPosition"
        anchorPosition={{ top: cursorPosition.top, left: cursorPosition.left }}
        open={suggestionMenuOpen}
        onClose={closeSuggestionMenu}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        disableAutoFocus
        disableEnforceFocus
        disableRestoreFocus>
        {suggestedItems.map((item, index) => (
          <MenuItem
            key={item.value}
            onClick={() => handleSuggestionSelect(item.value)}>
            {item.text}
          </MenuItem>
        ))}
      </Popover>
    </>
  );
};

export default InputWithSuggestionMenu;